import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Change 'portfolio-react-john-doe' to your repository name if different
export default defineConfig({
  plugins: [react()],
  base: '/portfolio-react-john-doe/'
})
