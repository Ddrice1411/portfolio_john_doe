import Hero from '../components/Hero'
import GithubModal from '../components/GithubModal'

export default function Home() {
  return (
    <>
      <Hero />
      <GithubModal />

      <section className="container py-5">
        <div className="row align-items-center g-5">
          <div className="col-12 col-lg-6">
            <h3 className="fw-semibold mb-3">À propos</h3>
            <p>Développeur web passionné par React et l’accessibilité. Je conçois des interfaces rapides et soignées.</p>
          </div>
          <div className="col-12 col-lg-6">
            <h4 className="mb-3">Compétences</h4>
            {[
              { label: 'HTML/CSS', val: 90 },
              { label: 'JavaScript', val: 85 },
              { label: 'React', val: 80 },
              { label: 'Bootstrap', val: 80 }
            ].map(s => (
              <div key={s.label} className="mb-3">
                <div className="d-flex justify-content-between"><span>{s.label}</span><span>{s.val}%</span></div>
                <div className="progress" role="progressbar" aria-valuenow={s.val} aria-valuemin="0" aria-valuemax="100">
                  <div className="progress-bar" style={{width: `${s.val}%`}}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
