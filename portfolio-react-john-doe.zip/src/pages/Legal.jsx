import { Helmet } from 'react-helmet-async'

export default function Legal() {
  return (
    <section className="container py-5">
      <Helmet>
        <meta name="robots" content="noindex" />
        <title>Mentions légales</title>
      </Helmet>

      <h1 className="mb-4 fw-semibold text-center">Mentions légales</h1>

      <div className="accordion" id="legalAccordion">
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingOne">
            <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#editor" aria-expanded="true" aria-controls="editor">L’éditeur du site</button>
          </h2>
          <div id="editor" className="accordion-collapse collapse show" data-bs-parent="#legalAccordion">
            <div className="accordion-body">
              John Doe — 123 Rue du Code, 75000 Paris — john@doe.dev
            </div>
          </div>
        </div>
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingTwo">
            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#host" aria-expanded="false" aria-controls="host">Hébergeur</button>
          </h2>
          <div id="host" className="accordion-collapse collapse" data-bs-parent="#legalAccordion">
            <div className="accordion-body">
              Raison sociale de l’hébergeur — adresse — téléphone.
            </div>
          </div>
        </div>
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingThree">
            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#credits" aria-expanded="false" aria-controls="credits">Crédits</button>
          </h2>
          <div id="credits" className="accordion-collapse collapse" data-bs-parent="#legalAccordion">
            <div className="accordion-body">
              Images : Pixabay — Favicon : Flaticon — Icônes : Bootstrap Icons.
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
