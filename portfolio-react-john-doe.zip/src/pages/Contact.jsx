export default function Contact() {
  return (
    <section className="container py-5">
      <h1 className="mb-4 fw-semibold text-center">Contact</h1>
      <div className="row g-4">
        <div className="col-12 col-lg-6">
          <form className="needs-validation" noValidate>
            {[
              { id: 'name', label: 'Nom', type: 'text' },
              { id: 'email', label: 'Courriel', type: 'email' },
              { id: 'phone', label: 'Téléphone', type: 'tel' },
              { id: 'subject', label: 'Sujet', type: 'text' }
            ].map(f => (
              <div className="mb-3" key={f.id}>
                <label htmlFor={f.id} className="form-label">{f.label}</label>
                <input required type={f.type} className="form-control" id={f.id} />
                <div className="invalid-feedback">Champ obligatoire</div>
              </div>
            ))}
            <div className="mb-3">
              <label htmlFor="message" className="form-label">Message</label>
              <textarea required className="form-control" id="message" rows="5"></textarea>
              <div className="invalid-feedback">Champ obligatoire</div>
            </div>
            <button className="btn btn-primary btn-hover" type="submit">Envoyer</button>
          </form>
        </div>
        <div className="col-12 col-lg-6">
          <h5 className="fw-semibold">Coordonnées</h5>
          <p>123 Rue du Code, 75000 Paris</p>
          <p><a className="text-reset" href="tel:+33123456789">+33 1 23 45 67 89</a> — <a className="text-reset" href="mailto:john@doe.dev">john@doe.dev</a></p>
          <div className="ratio ratio-16x9 rounded overflow-hidden">
            <iframe
              src="https://www.google.com/maps?q=Paris&output=embed"
              title="Google Map"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
    </section>
  )
}
