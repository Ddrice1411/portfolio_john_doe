import ServiceCard from '../components/UI/ServiceCard'

export default function Services() {
  return (
    <section className="container py-5">
      <h1 className="mb-4 fw-semibold text-center">Services</h1>
      <div className="row g-4">
        <div className="col-12 col-md-6 col-lg-4">
          <ServiceCard icon="bi-code" title="Intégration & Frontend">
            Intégration responsive avec React et Bootstrap, accessibilité et bonnes pratiques.
          </ServiceCard>
        </div>
        <div className="col-12 col-md-6 col-lg-4">
          <ServiceCard icon="bi-speedometer2" title="Performance">
            Optimisations Lighthouse, lazy-loading et stratégie d’assets moderne.
          </ServiceCard>
        </div>
        <div className="col-12 col-md-6 col-lg-4">
          <ServiceCard icon="bi-search" title="SEO de base">
            Balises sémantiques, méta-données, et bonnes pratiques pour le référencement.
          </ServiceCard>
        </div>
      </div>
    </section>
  )
}
