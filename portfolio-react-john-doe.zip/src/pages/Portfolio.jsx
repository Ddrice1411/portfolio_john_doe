export default function Portfolio() {
  const items = Array.from({ length: 6 }).map((_, i) => ({
    id: i + 1,
    title: `Projet ${i + 1}`,
    img: `/assets/project-${(i % 3) + 1}.svg`
  }))

  return (
    <section className="container py-5">
      <h1 className="mb-4 fw-semibold text-center">Portfolio</h1>
      <div className="row g-4">
        {items.map(p => (
          <div className="col-12 col-md-6 col-lg-4" key={p.id}>
            <div className="card h-100 shadow-hover bg-hover">
              <img src={p.img} className="card-img-top" alt={p.title} />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{p.title}</h5>
                <p className="card-text">Courte description du projet et des technologies utilisées.</p>
                <div className="mt-auto">
                  <a className="btn btn-primary btn-hover" href="#">Voir le projet</a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
