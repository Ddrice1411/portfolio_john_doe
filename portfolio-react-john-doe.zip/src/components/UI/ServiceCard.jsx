export default function ServiceCard({ icon, title, children }) {
  return (
    <div className="card h-100 shadow-hover bg-hover">
      <div className="card-body">
        <div className="d-flex align-items-center gap-2 mb-2">
          <i className={`bi ${icon} fs-4`}></i>
          <h5 className="card-title mb-0">{title}</h5>
        </div>
        <p className="card-text">{children}</p>
      </div>
    </div>
  )
}
