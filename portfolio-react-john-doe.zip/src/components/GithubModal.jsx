import { useEffect, useRef, useState } from 'react'

export default function GithubModal() {
  const [data, setData] = useState(null)
  const loadedRef = useRef(false)

  useEffect(() => {
    if (loadedRef.current) return
    loadedRef.current = true
    fetch('https://api.github.com/users/github-john-doe')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
  }, [])

  return (
    <div className="modal fade" id="githubModal" tabIndex="-1" aria-hidden="true">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Profil GitHub</h5>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div className="modal-body">
            {!data ? (
              <p className="mb-0">Chargement…</p>
            ) : (
              <div className="d-flex gap-3 align-items-center">
                <img src={data.avatar_url} alt="avatar" width="64" height="64" className="rounded-circle" />
                <div>
                  <p className="mb-1 fw-semibold">{data.name ?? data.login}</p>
                  <p className="mb-1">Repos publics : {data.public_repos}</p>
                  <a href={data.html_url} target="_blank" rel="noopener" className="btn btn-sm btn-outline-primary">Voir sur GitHub</a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
