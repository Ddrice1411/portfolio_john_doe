import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-light mt-auto py-5 border-top">
      <div className="container">
        <div className="row g-4">
          <div className="col-12 col-md-4">
            <h5 className="fw-semibold">John Doe</h5>
            <address className="mb-2">
              123 Rue du Code<br />
              75000 Paris, France<br />
              <a className="text-reset" href="tel:+33123456789">+33 1 23 45 67 89</a><br />
              <a className="text-reset" href="mailto:john@doe.dev">john@doe.dev</a>
            </address>
            <div className="d-flex gap-3 fs-4">
              <a href="https://github.com/github-john-doe" target="_blank" rel="noopener nofollow" className="text-reset social-link">
                <i className="bi bi-github"></i>
              </a>
              <a href="https://twitter.com/" target="_blank" rel="noopener nofollow" className="text-reset social-link">
                <i className="bi bi-twitter"></i>
              </a>
              <a href="https://www.linkedin.com/" target="_blank" rel="noopener nofollow" className="text-reset social-link">
                <i className="bi bi-linkedin"></i>
              </a>
            </div>
          </div>
          <div className="col-12 col-md-4">
            <h5 className="fw-semibold">Navigation</h5>
            <ul className="list-unstyled">
              <li><Link to="/" className="footer-link">Accueil</Link></li>
              <li><Link to="/services" className="footer-link">Services</Link></li>
              <li><Link to="/portfolio" className="footer-link">Réalisations</Link></li>
              <li><Link to="/contact" className="footer-link">Contact</Link></li>
            </ul>
          </div>
          <div className="col-12 col-md-4">
            <h5 className="fw-semibold">Dernières réalisations</h5>
            <ul className="list-unstyled">
              <li><Link to="/portfolio" className="footer-link">Projet A</Link></li>
              <li><Link to="/portfolio" className="footer-link">Projet B</Link></li>
              <li><Link to="/portfolio" className="footer-link">Projet C</Link></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  )
}
