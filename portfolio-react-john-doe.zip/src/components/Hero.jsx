export default function Hero({ onMore }) {
  return (
    <header className="position-relative text-white">
      <img src="/hero.svg" alt="Hero" className="w-100 object-fit-cover" style={{height: '70vh'}} />
      <div className="position-absolute top-50 start-50 translate-middle text-center">
        <h1 className="display-4 fw-semibold text-shadow">John Doe</h1>
        <h2 className="h4 mb-4 text-shadow">Développeur Web</h2>
        <button className="btn btn-primary btn-lg" onClick={onMore} data-bs-toggle="modal" data-bs-target="#githubModal">En savoir plus</button>
      </div>
    </header>
  )
}
