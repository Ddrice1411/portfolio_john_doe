# Créez un Portfolio avec REACT.JS – Document de rendu

## 1) Mission
Créer et rendre fonctionnel le site portfolio de John Doe (développeur web / CEF) en **React.js** avec **Bootstrap**, conforme W3C et optimisé SEO, à livrer sous forme de **lien de repository GitHub**.

## 2) Client
John Doe, fin de formation de développeur web, souhaite un site pour présenter son profil et rechercher une alternance. Le projet doit être versionné sur GitHub.

## 3) Identité graphique
- Police : **Nunito Sans** (Google Fonts) — 400/600
- Icônes : **Bootstrap Icons**
- Palette : couleurs par défaut Bootstrap
- Logo : textuel en navbar
- Favicon : depuis Flaticon (placeholder fourni `public/favicon.svg`)

## 4) Livrables
- Lien du repository GitHub contenant **tout le code** du projet
- (Optionnel) Lien de démo (GitHub Pages / Netlify / Vercel)

## 5) Contenu des pages
- **Accueil** : hero pleine largeur (image), titres h1/h2 centrés, bouton « En savoir plus » (ouvre une **modale**)
- **Services** : cartes Bootstrap (couleur + ombre au survol), layout responsive
- **Réalisations** : au moins 6 projets en **cards** (couleur + ombre au survol, bouton qui s’éclaircit)
- **Contact** : formulaire (nom, courriel, téléphone, sujet, message — tous requis), coordonnées + Google Map
- **Mentions légales** : éditeur, hébergeur, crédits (Pixabay, Flaticon), présentation en **accordéon**, **noindex**

## 6) Éléments communs
- **Header** : logo à gauche, navigation à droite, menu hamburger sur mobile, lien actif en couleur/gras/souligné
- **Footer** : 3 colonnes (coordonnées + réseaux, navigation, dernières réalisations). Liens externes `target="_blank"` et `rel="nofollow"`
- **Modale GitHub** : infos depuis `https://api.github.com/users/github-john-doe`, récupérées **une seule fois** via `useEffect`

## 7) Effets graphiques (CSS)
- Menu : soulignement au survol, actif visible
- Cards : ombre + fond `#efefef` au survol
- Boutons : fond qui s’assombrit au survol
- Footer : icônes blanches au survol, liens en gras au survol
- Transitions CSS pour la fluidité

## 8) Installation & exécution
```bash
npm install
npm run dev
# build prod
npm run build
```

## 9) Déploiement (GitHub Pages)
- `vite.config.js` → `base: '/portfolio-react-john-doe/'` (à ajuster si le repo a un autre nom)
- `npm run deploy`

## 10) Organisation du code
- `src/components` pour les composants UI (Header, Footer, Hero, GithubModal, etc.)
- `src/pages` pour les pages (Home, Services, Portfolio, Contact, Legal)
- `src/styles/global.css` pour les effets transverses

## 11) Personnalisation
- Remplacer les images SVG de `public/` par vos visuels
- Mettre à jour les liens sociaux et les coordonnées
- Adapter les textes et les compétences

---
Bon rendu !
